<?php

namespace App\Http\Controllers;

use App\Http\Resources\StudentResouce;
use App\Models\Persona;
use App\Models\Student;
use App\Models\User;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index()
    {
      
        return response()->json([
            'ok'=>true,
            'Student'=> Student::with('users','personas')->get()
        ]);
    }

    public function store(Request $request)
    {
        // return $request;
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'ci'=>'required',
            'cellphone'=>'required',
        ]);

       $per = new Persona();
       $per->first_name =   $request->first_name;
       $per->last_name  =   $request->last_name;
       $per->ci  =   $request->ci;
       $per->cellphone  =   $request->cellphone;
        $per->save();

        $request->validate([
            'email'=>'required|email|unique:users',
            'password'=>'required|confirmed',
        ]);
        
        $user =new User();
        $user->email=$request->email;
        $user->password=bcrypt($request->password);
        $user->save();

        $token = $user->createToken('auth_token')->plainTextToken;
        $user->remenber_token =$token;
        $user->assignRole('student');

        

        $student = new Student();
        $student->user_id = $user->id;
        $student->persona_id = $per->id;  
        $student->colegio_id = $request->colegio_id;  
        $student->save();
        
        // return new AdminResource($admin);
        

        return response()->json([
            'ok'=>true,
            'msg'=>'Registrado correctamente',
            'access_token'=>$token,
            'studen'=>$student
        ],200);
    }

    public function create(Request $request)
    {  
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'ci'=>'required',
            'cellphone'=>'required',
        ]);

       $per = new Persona();
       $per->first_name =   $request->first_name;
       $per->last_name  =   $request->last_name;
       $per->ci  =   $request->ci;
       $per->cellphone  =   $request->cellphone;
  
        $per->save();

        $request->validate([
            'email'=>'required|email|unique:users',
            'password'=>'required|confirmed',
        ]);
        
        $user =new User();
        $user->email=$request->email;
        $user->password=bcrypt($request->password);
        $user->save();


        $token = $user->createToken('auth_token')->plainTextToken;
        $user->assignRole('studend');
        
        $student = new Student();
        $student->user_id = $user->id;
        $student->persona_id = $per->id;
       
        $student->save();
        
        return new StudentResouce($student);
        // return response()->json([
        //     'ok'=>true,
        //     'msg'=>'Registrado correctamente',
        //     'access_token'=>$token
        // ],200);
    }

    public function update(Request $request,  Student $student)
    {
     
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'ci'=>'required',
            'cellphone'=>'required',
      
        ]);

        $students = Student::findOrFail($student->id)
                        ->personas()
                        ->where('id',$student->persona_id)->first();

        $students = Student::findOrFail($student->id)            
                        ->users()
                        ->where('id',$student->user_id)->first();
        $students->update($request->all());
        return new StudentResouce($students);

        // return response()->json([
        //     'ok'=>true,
        //     'admin'=>$admin,
        //     'message'=>'Administrador actualizado correctamente'
        // ],200);
    }

    public function destroy(Student $student)
    {
        $student ->delete();
        // return response()->json([
        //     'ok'=>true,
        //     'message'=>'Administrador eliminado correctamente'
        // ],200);

        return new StudentResouce($student);
    }
}
