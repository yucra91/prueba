<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\AccesoRequest;
use App\Http\Requests\PersonaRequest;
use App\Http\Requests\UserRequest;
use App\Http\Resources\AdminResource;
use App\Models\Persona;
use App\Models\Student;
use App\Models\User;
use Carbon\Carbon;
// use Spatie\Permission\Traits\HasRoles;
use Spatie\Permission\Models\Role;
use Database\Seeders\RolSeeder;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use PharIo\Manifest\Email;
use Validator;

use function PHPUnit\Framework\returnSelf;

// use App\Http\Requests\UserRequest;

// use App\Models\User;

class AutenticarController extends Controller
{
    public function login(Request $request)
    {

        // $credenciales= $request->validate([
        //     'email' => ['required', 'email'],
        //     'password' => ['required']
        // ]);

        // if(Auth::attempt($credenciales)){
        //     $user = Auth::user();
        //     $token= $user->createToken('auth_token')->plainTextToken;
        //             return response()->json([
        //                 'success'=>true,
        //                 "token"=>$token,
        //                 'user'=>$user
        //             ]);
        // }



            $user =User::with('roles')->where('email', $request->email)->first();
            if(isset($user)){
                if(Hash::check($request->password,$user->password)){
                    $token= $user->createToken('auth_token')->plainTextToken;
                    return response()->json([
                        'success'=>true,
                        "token"=>$token,
                        'user'=>$user
                    ]);
                }

                return response()->json([
                    'success'=>false,
                    'message'=>'Contraseña incorrecta'
                ]);
            }
       
            return response()->json([
                'success'=>false, 
                'message'=>'gmail no existe'
            ],500);
        

        
    }
 

    // public function Login(AccesoRequest $request)
    // {

    //     $user = User::with('roles')->where('email', $request->email)->first();

    //     if (! $user || ! Hash::check($request->password, $user->password)) {
  
    //         throw ValidationException::withMessages([
    //             'msg' => ['la credenciales son incorrecta'],
    //         ]);
    //     }
     
    //     $token= $user->createToken('auth_token')->plainTextToken;
    //     return response()->json([
    //         'ok'=>true,
    //         'token'=>$token,
    //         'usuario'=>$user
    //     ],200);
    // }


    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            'message ' => 'Successfully logged out'
        ]) ;
    }

       
  

}
